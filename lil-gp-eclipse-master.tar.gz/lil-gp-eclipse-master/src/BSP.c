/*
 * BSP.c
 *
 *  Created on: Mar 8, 2016
 *      Author: Khawaja Asif Majeed
 */


# include "BSP.h"
int countRevisit = 0;
/*
 *
 * Binary Space Partition BSP Structure...
 *
 */

static int fitness_cases = 200;






long dist(double a[], double b[])
{
	long int dist= 0;
	for (int i = 0 ; i<fitness_cases; i++)
		dist=dist+(a[i]-b[i]);
	return dist;

}

void copy_int_array(double a[],double b[])
{
	for(int i = 0; i<fitness_cases; i++)
		a[i] = b[i];
}





/*
 *
 * This Method inserts a node within the Binary Tree...
 *
 */

void insert(node ** tree, double val[])
{
    node *temp = NULL;
    if(!(*tree))
    {
        temp = (node *)malloc(sizeof(node));
        temp->left = temp->right = NULL;
        copy_int_array(temp->datum , val);
        *tree = temp;
        return;
    }

    if(dist(val,(*tree)->datum)<0.0)
    {
        insert(&(*tree)->left, val);
    }
    else if(dist(val, (*tree)->datum)>0.0)
    {
        insert(&(*tree)->right, val);
    }
    else
    {
    	countRevisit = countRevisit+1;

    }

}


void print_BSP_Tree(node *tree, FILE *f)
{



if (tree)
    {
		fprintf(f,"Evaluation of Tree  [");
    	for(int j=0; j<fitness_cases;j++)
    	{
    		fprintf(f,"%5.2f, ",tree->datum[j]);
    		if (j != fitness_cases-1)
    			fprintf(f,", ");
    	}
    	fprintf (f,"]\n");
        print_BSP_Tree(tree->left , f);
        print_BSP_Tree(tree->right, f);

    }
else
{
	fprintf(f,"No Data in BSP...");

}


}
/*
void print_preorder(node * tree)
{
    if (tree)
    {
    	for(int j=0; j<fitness_cases;j++)
    		printf("%d  ",tree->datum[j]);
    	printf ("\n");
        print_preorder(tree->left);
        print_preorder(tree->right);
    }

}
*/

/*
void print_inorder(node * tree)
{
    if (tree)
    {
        print_inorder(tree->left);
        for(int j=0; j<fitness_cases;j++)
        	printf("%d  ",tree->datum[j]);
        printf("\n");
        print_inorder(tree->right);
    }
}
*/

/*
void print_postorder(node * tree)
{
    if (tree)
    {
        print_postorder(tree->left);
        print_postorder(tree->right);
        for(int j=0; j<fitness_cases;j++)
        	printf("%d  ",tree->datum[j]);
        printf("\n");
    }
}
*/
void deltree(node * tree)
{
    if (tree)
    {
        deltree(tree->left);
        deltree(tree->right);
        free(tree);
    }
}
/*
node* search(node ** tree, int val[])
{
    if(!(*tree))
    {
        return NULL;
    }

    if(dist(val , (*tree)->datum)<0)
    {
        search(&((*tree)->left), val);
    }
    else if(dist(val, (*tree)->datum)>0)
    {
        search(&((*tree)->right), val);
    }
    else if(dist(val, (*tree)->datum)==0)
    {
        return *tree;
    }
}
*/


//int main(void)
//{
//    node *root;
//    node *tmp;
//    //int i;
//
//    root = NULL;
//    /* Inserting nodes into tree */
//
//
//    int b[4][5] = {{1,2,3,4,5}, {5,4,3,2,1}, {2,4,6,8,10}, {1,3,5,7,9}};
//
//    for (int i = 0; i<4 ; i++)
//    	insert(&root,b[i]);
//
//    /* Printing nodes of tree */
//    printf("Pre Order Display\n");
//    print_preorder(root);
//
//    printf("In Order Display\n");
//    print_inorder(root);
//
//    printf("Post Order Display\n");
//    print_postorder(root);
//
//    /* Search node into tree */
//    //tmp = search(&root, 4);
//   /* if (tmp)
//    {
//        printf("Searched node=%d\n", tmp->datum);
//    }
//    else
//    {
//        printf("Data Not found in tree.\n");
//    }
//*/
//    /* Deleting all nodes of tree */
//    deltree(root);
//}
