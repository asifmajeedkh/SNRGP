/*
 * BSP.h
 *
 *  Created on: Mar 8, 2016
 *      Author: asif
 */

#ifndef BSP_H_
#define BSP_H_

#include <stdio.h>
#include <stdlib.h>
#include "app.h"


struct BSP {
	double datum[200];
	struct BSP * right, * left;
};

typedef struct BSP node;
void insert(node ** tree, double val[]);

extern int countRevisit;

#endif /* BSP_H_ */



